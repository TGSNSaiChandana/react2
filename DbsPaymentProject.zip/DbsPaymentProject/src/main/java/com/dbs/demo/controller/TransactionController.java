package com.dbs.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.demo.exception.InvalidTransactionIdException;
import com.dbs.demo.model.Transaction;
import com.dbs.demo.service.TransactionService;

@RestController
public class TransactionController {
	@Autowired
    TransactionService transactionService;

    @CrossOrigin({"http://localhost:3000/", "http://localhost:3000/"})
    @GetMapping("transactionDetails/{transactionId}")
    public ResponseEntity<Transaction> getTransactionDetails(@PathVariable("transactionId") int transactionId) throws InvalidTransactionIdException {

        Transaction transaction = transactionService.getTransactionDetails(transactionId);
        return new ResponseEntity<>(transaction, HttpStatus.OK);

    }

    @CrossOrigin({"http://localhost:4200/", "http://localhost:4200/"})
    @PostMapping("/addTransactionDetails")
    public ResponseEntity<Integer> setTransactionDetails(@RequestBody Transaction transaction) throws Exception {

        Transaction transaction1 = transactionService.setTransactionDetails(transaction);
        return new ResponseEntity<>(transaction1.getTransactionId(), HttpStatus.CREATED);

    }

}
