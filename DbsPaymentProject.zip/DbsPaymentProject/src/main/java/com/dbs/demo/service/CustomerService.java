package com.dbs.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.demo.exception.CurrencyCodeNotFoundException;
import com.dbs.demo.exception.CustomerIdNotFoundException;
import com.dbs.demo.model.Currency;
import com.dbs.demo.model.Customers;
import com.dbs.demo.repository.CustomerRepo;

@Service
public class CustomerService {
	@Autowired
	CustomerRepo customerRepository;

	@Autowired
	CurrencyService currencyService;
	public Customers fetchCustomerDetails(String id) throws CustomerIdNotFoundException {

		Optional<Customers> customer = customerRepository.findById(id);

		if (customer.isEmpty()) throw new CustomerIdNotFoundException("Invalid Customer Id");
		else return customer.get();

	}
	public List<Customers> findAllCustomers(){

		return customerRepository.findAll();
	}

	public float updateCurrencyCodeValue(Customers customer, String currencyCode, float amount) throws CurrencyCodeNotFoundException {

		float balance = customer.getClearBalance();
		Currency currency = currencyService.getCurrencyDetails(currencyCode);
		balance *= currency.getConversionRate();

		customer.setClearBalance(balance);
		customerRepository.save(customer);

		return customer.getClearBalance();

	}

	public void updateBalance(String customerId, float clearBalance) {

		Customers customer = customerRepository.findById(customerId).get();
		customer.setClearBalance(clearBalance);
		customerRepository.save(customer);

	}


}
