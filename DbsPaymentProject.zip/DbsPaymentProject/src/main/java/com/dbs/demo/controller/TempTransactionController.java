package com.dbs.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.demo.exception.BankBICNotFoundException;
import com.dbs.demo.exception.CurrencyCodeNotFoundException;
import com.dbs.demo.exception.CustomerIdNotFoundException;
import com.dbs.demo.exception.InvalidMessageCodeException;
import com.dbs.demo.exception.InvalidTransactionIdException;
import com.dbs.demo.exception.TransferTypeNotFoundException;
import com.dbs.demo.model.TempTransactionDetails;
import com.dbs.demo.model.Transaction;
import com.dbs.demo.service.Status;
import com.dbs.demo.service.TempTransactionService;

@RestController
public class TempTransactionController {
	 @Autowired
	    TempTransactionService tempTransactionService;

	    @GetMapping("/getTransactionDetails/{transactionId}")
	    public ResponseEntity<Transaction> getTransactionDetails(@PathVariable("transactionId") int transactionId) throws InvalidTransactionIdException, CustomerIdNotFoundException, BankBICNotFoundException, CurrencyCodeNotFoundException, TransferTypeNotFoundException, InvalidMessageCodeException {

	        Transaction transactionDetails = tempTransactionService.getTransactionDetails(transactionId);
	        return new ResponseEntity<>(transactionDetails, HttpStatus.OK);

	    }

	    @RequestMapping("/setTransactionDetails")
	    public ResponseEntity<Status> setTransactionDetails(@RequestBody TempTransactionDetails tempTransactionDetails) {

	        Status status = tempTransactionService.setTransactionDetails(tempTransactionDetails);
	        return new ResponseEntity<>(status, HttpStatus.CREATED);

	    }

}
