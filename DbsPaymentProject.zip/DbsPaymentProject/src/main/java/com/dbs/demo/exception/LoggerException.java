package com.dbs.demo.exception;

public class LoggerException extends Exception {

    public LoggerException() { super(); }

    public LoggerException(String exception) { super(exception); }

    public LoggerException(Exception exception){ super(exception); }

}