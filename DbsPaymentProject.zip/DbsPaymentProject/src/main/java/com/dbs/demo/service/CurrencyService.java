package com.dbs.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.demo.exception.CurrencyCodeNotFoundException;
import com.dbs.demo.model.Currency;
import com.dbs.demo.repository.CurrencyRepo;

@Service
public class CurrencyService {
	@Autowired
    CurrencyRepo currencyRepository;

    public Currency getCurrencyDetails(String currencyCode) throws CurrencyCodeNotFoundException {

        Optional<Currency> currency = currencyRepository.findById(currencyCode);

        if (currency.isEmpty()) throw new CurrencyCodeNotFoundException("Invalid Currency Code");
        else return currency.get();

    }

    public float getConversionRate(String currencyCode) throws CurrencyCodeNotFoundException {

        Optional<Currency> currency = currencyRepository.findById(currencyCode);

        if (currency.isEmpty()) throw new CurrencyCodeNotFoundException("Invalid Currency Code");
        else return currency.get().getConversionRate();

    }

    public List<Currency> getAllCurrencyDetails() {

        return currencyRepository.findAll();

    }

}
