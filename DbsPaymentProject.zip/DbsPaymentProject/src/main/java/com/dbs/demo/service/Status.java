package com.dbs.demo.service;

public class Status {
	private String message;

    public Status() {
        super();
    }

    public String getMessage() {

        return message;
    }

    public void setMessage(String message) {

        this.message = message;
    }

}
