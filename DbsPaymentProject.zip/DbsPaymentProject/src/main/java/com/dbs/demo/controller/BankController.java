package com.dbs.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.demo.exception.BankBICNotFoundException;
import com.dbs.demo.model.Banks;
import com.dbs.demo.service.BankService;

@RestController
public class BankController {

    @Autowired
    BankService bankService;

    @CrossOrigin(value="http://localhost:3000/")
    @GetMapping("/bankDetails/{BIC}")
    public ResponseEntity<Banks> getBankDetails(@PathVariable("BIC") String BIC) throws BankBICNotFoundException {

        Banks bank = bankService.fetchBankDetails(BIC);
        return new ResponseEntity<>(bank, HttpStatus.OK);

    }
    /*@GetMapping("/")
	public List<Banks>  listAllBank(){
		return bankService.list();
	}*/

}
