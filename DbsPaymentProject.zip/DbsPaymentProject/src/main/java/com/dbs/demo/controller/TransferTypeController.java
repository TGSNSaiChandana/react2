package com.dbs.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.demo.exception.TransferTypeNotFoundException;
import com.dbs.demo.model.TransferType;
import com.dbs.demo.service.TransferTypeService;

@RestController
public class TransferTypeController {
	@Autowired
    TransferTypeService transferTypeService;

    @CrossOrigin("http://localhost:3000/")
    @GetMapping("/transferTypeDetails/{transferTypeCode}")
    public ResponseEntity<TransferType> getTransferTypeDetails(@PathVariable("transferTypeCode") String transferTypeCode) throws TransferTypeNotFoundException {

        TransferType transferType = transferTypeService.getTransferTypeDetails(transferTypeCode);
        return new ResponseEntity<>(transferType, HttpStatus.OK);
    }

}
