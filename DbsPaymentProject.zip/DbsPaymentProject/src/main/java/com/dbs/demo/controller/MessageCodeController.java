package com.dbs.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.demo.exception.InvalidMessageCodeException;
import com.dbs.demo.model.MessageCode;
import com.dbs.demo.service.MessageCodeService;

@RestController
public class MessageCodeController {

    @Autowired
    MessageCodeService messageCodeService;

    @CrossOrigin("http://localhost:3000/")
    @GetMapping("messageCodeDetails/{messageCode}")
    public ResponseEntity<MessageCode> getMessageCodeDetails(@PathVariable("messageCode") String messageCode) throws InvalidMessageCodeException {

        MessageCode messageCode1 = messageCodeService.getMessageCodeDetails(messageCode);
        return new ResponseEntity<>(messageCode1, HttpStatus.OK);

    }

}
