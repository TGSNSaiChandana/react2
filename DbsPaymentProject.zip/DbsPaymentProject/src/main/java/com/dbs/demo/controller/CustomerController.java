package com.dbs.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.demo.exception.CustomerIdNotFoundException;
import com.dbs.demo.model.Customers;
import com.dbs.demo.service.CustomerService;

@RestController
//@RequestMapping("/dbs")

public class CustomerController {
	@Autowired
    CustomerService customerService;

    @CrossOrigin("http://localhost:3000/")
    @GetMapping("/customerDetails/{customerId}")
    public ResponseEntity<Customers> getCustomerDetails(@PathVariable("customerId") String customerId) throws CustomerIdNotFoundException {

        Customers customer = customerService.fetchCustomerDetails(customerId);
        return new ResponseEntity<>(customer, HttpStatus.OK);
    }
    @CrossOrigin("http://localhost:3000/")
    @GetMapping("/allCustomerDetails")
    public ResponseEntity<List<Customers>> getAllCustomerData(){

        List<Customers> customers = customerService.findAllCustomers();
        return new ResponseEntity<>(customers, HttpStatus.OK);

    }

}
