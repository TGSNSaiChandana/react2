package com.dbs.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbsPaymentProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbsPaymentProjectApplication.class, args);
	}

}
