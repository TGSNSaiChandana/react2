package com.dbs.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.demo.exception.BankBICNotFoundException;
import com.dbs.demo.model.Banks;
import com.dbs.demo.repository.BankRepo;

@Service
public class BankService {
	@Autowired
    BankRepo receiverRepository;

    public Banks fetchBankDetails(String BIC) throws BankBICNotFoundException {

        Optional<Banks> bank = receiverRepository.findById(BIC);

        if (bank.isEmpty()) throw new BankBICNotFoundException("Invalid Bank BIC");
        else return bank.get();

    }

	/*public List<Banks> list() {
		// TODO Auto-generated method stub
		try {
			return BankRepo.findAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	

}
