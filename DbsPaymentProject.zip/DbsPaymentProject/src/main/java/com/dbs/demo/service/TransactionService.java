package com.dbs.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.demo.exception.InvalidTransactionIdException;
import com.dbs.demo.model.Transaction;
import com.dbs.demo.repository.TransactionRepo;

@Service
public class TransactionService {

    @Autowired
    TransactionRepo transactionRepository;



    @Autowired
    CustomerService customerService;



    @Autowired
    CurrencyService currencyService;



    @Autowired
    TransferTypeService transferTypeService;



    Status status = new Status();

    public Transaction getTransactionDetails(int transactionId) throws InvalidTransactionIdException {



        Optional<Transaction> transaction = transactionRepository.findById(transactionId);
        if (transaction.isEmpty()) throw new InvalidTransactionIdException("Invalid Transaction Id");
        else return transaction.get();
    }


    public Transaction setTransactionDetails(Transaction transaction) {

        try {
            float conversionRate = currencyService.getConversionRate(transaction.getCurrency().getCurrencyCode());
            float amount = transaction.getInrAmount();
            double tax = (amount * conversionRate) * 0.025;
            transaction.setTransferFees((float)tax);
            double totalAmount = (amount * conversionRate) + tax;
            float clearBalance = customerService.fetchCustomerDetails(transaction.getCustomer().getCustomerId()).getClearBalance();
            double totalClearBalance = clearBalance - totalAmount;
            transaction.getCustomer().setClearBalance((float)totalClearBalance);
            customerService.updateBalance(transaction.getCustomer().getCustomerId(), (float)totalClearBalance);
            transaction.getCustomer().setClearBalance((float) totalClearBalance);
            transactionRepository.save(transaction);
            return transactionRepository.findById(transaction.getTransactionId()).get();
        } catch (Exception e) {

            status.setMessage("Unsuccessful");
            return null;

        }

    }

}
