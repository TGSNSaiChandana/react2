package com.dbs.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.demo.exception.InvalidMessageCodeException;
import com.dbs.demo.model.MessageCode;
import com.dbs.demo.repository.MessageCodeRepo;

@Service
public class MessageCodeService {

    @Autowired
    MessageCodeRepo messageCodeRepository;

    public MessageCode getMessageCodeDetails(String messageCode) throws InvalidMessageCodeException {

        Optional<MessageCode> messageCode1 = messageCodeRepository.findById(messageCode);
        if (messageCode1.isEmpty()) throw new InvalidMessageCodeException("Invalid Message Code");
        return messageCode1.get();

    }

}
