package com.dbs.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.demo.exception.TransferTypeNotFoundException;
import com.dbs.demo.model.TransferType;
import com.dbs.demo.repository.TransferTypeRepo;

@Service
public class TransferTypeService {
	 @Autowired
	    TransferTypeRepo transferTypeRepository;

	    public TransferType getTransferTypeDetails(String transferTypeCode) throws TransferTypeNotFoundException {

	        Optional<TransferType> transferType = transferTypeRepository.findById(transferTypeCode);
	        if (transferType.isEmpty()) throw new TransferTypeNotFoundException("Invalid Transfer Type");

	        return transferType.get();
	    }

}
