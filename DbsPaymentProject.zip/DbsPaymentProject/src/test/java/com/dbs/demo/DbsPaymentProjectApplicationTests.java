package com.dbs.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbsPaymentProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
